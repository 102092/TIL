package lab.board.model;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Properties;



public class BbsDAO {
	
	public Connection dbCon() {
		Connection con = null;
		try {
			Properties prop = new Properties();
			prop.load(new FileInputStream("C:/workspace2/web2/WebContent/WEB-INF/dbinfo.properties"));
			Class.forName(prop.getProperty(("driver")));
			con = DriverManager.getConnection(prop.getProperty("url"),prop.getProperty("user"),prop.getProperty("pwd"));
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return con;
	}

	public void dbClose(Connection con, Statement stat,ResultSet rs) {
		try {
			if(rs!=null) rs.close();
			if(stat!=null) stat.close();
			if(con!=null) con.close();
		}catch (Exception e) {
			e.printStackTrace();
		}		
	}
	
	public int getPageCount(int numPerPage) {
		//전체 글 개수를 조회해서 페이지 개수 계산해서 리턴
		int total = 0;
		Connection con = null;
		PreparedStatement stat = null;
		String sql = "select count(*) from bbs ";
		ResultSet rs = null;
		try {
			con = dbCon();
			stat = con.prepareStatement(sql);
			rs = stat.executeQuery();
			if(rs.next()) {
				total = rs.getInt(1);
				
			}
		}catch (Exception e) {
				e.printStackTrace();
		}finally{
				dbClose(con, stat, rs);
		}
		int pageCount = (int) Math.ceil(total/(double)numPerPage); //0이 리턴될 수 도 있음
		pageCount = Math.max(pageCount, 1); 
		return pageCount;
		
		
	}
	
	public int insertBbs(BbsVO form) {
		int rows = 0;
		Connection con = null;
		PreparedStatement stat = null;
		String sql = "insert into bbs (bid, subject, writer, password, idate, contents,email, ip, fileYN) values ( bbs_seq.nextval,?,?,?, sysdate,?,?,?,?)";
		ResultSet rs = null;
		
		
		try {
			con = dbCon();
			stat = con.prepareStatement(sql);

			stat.setString(2, form.getSubject());
			stat.setString(3, form.getWriter());
			stat.setString(4, form.getPassword());
			stat.setString(6, form.getContents());			
			stat.setString(7, form.getEmail());
			stat.setString(8, form.getIp());
			stat.setString(9, form.getFileYN());
			
			rows = stat.executeUpdate();
		}catch (Exception e) {
				e.printStackTrace();
		}finally{
				dbClose(con, stat, rs);
		}

		return rows;
	}
	
	public ArrayList<BbsVO> getBbsList(int page, int numPerPage){
		//페이지 번호에 해당하는 게시글 10개를 검색해서 리턴
		ArrayList<BbsVO> lists = new ArrayList<BbsVO>();
		Connection con = null;
		PreparedStatement stat = null;
		int start = (page-1) * numPerPage;
		int end = page * numPerPage;
		String sql = "select bid, subject, writer, idate, rcount from bbs where bid > "+ start +" and bid <=" + end + " order by bid desc ";
		ResultSet rs = null;
		try {
			con = dbCon();
			stat = con.prepareStatement(sql);
			rs = stat.executeQuery();
			while(rs.next()) {
				BbsVO bbs = new BbsVO();
				bbs.setBid(rs.getInt("bid"));
				bbs.setSubject(rs.getString("subject"));
				bbs.setWriter(rs.getString("writer"));
				bbs.setIdate(rs.getDate("idate"));
				bbs.setrcount(rs.getInt("rcount"));						
				lists.add(bbs);				
			}
		}catch (Exception e) {
				e.printStackTrace();
		}finally{
				dbClose(con, stat, rs);
		}
		return lists;
	}
		
}
