package lab.board.controller;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collection;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import lab.board.model.BbsDAO;
import lab.board.model.BbsVO;
import lab.board.model.FileInfoVO;


@WebServlet("/write.do")
@MultipartConfig
public class BbsWriteAction extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public BbsWriteAction() {
        super();
     }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=utf-8");
		response.sendRedirect("./bbs_write.jsp");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=utf-8");
		BbsDAO dao = new BbsDAO();
		BbsVO form = null;
		form = new BbsVO();
		String fileFlag = "N"; 
		if(request.getParameter("upload") !=null ) {
				fileFlag ="Y";
		}
		
		form.setFileYN(fileFlag);
		form.setWriter(request.getParameter("writer"));
		form.setPassword(request.getParameter("password"));
		form.setSubject(request.getParameter("subject"));
		form.setEmail(request.getParameter("email"));
		form.setContents(request.getParameter("contents"));
		form.setIp(request.getRemoteAddr());
		if(dao.insertBbs(form) > 0) {
			response.sendRedirect("./list.do");
		}
	}

	protected void uploadProc(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = "C:/boardFile";
		Collection<Part> parts = request.getParts();
		String saveFile = null;
		
		File isDir = new File(path);
		if(!isDir.isDirectory()) {
			isDir.mkdir();
		} 

		
		for(Part part : parts) {
			if(part.getContentType() !=null) { // upload된 파일은 여기로
				String fileName = part.getSubmittedFileName();
				if(fileName != null) {
					saveFile = fileName.substring(0,fileName.lastIndexOf("."))+"_"+System.currentTimeMillis() + fileName.substring(fileName.lastIndexOf("."));
					part.write(saveFile);
					System.out.println("file저장완료");
					FileInfoVO file = new FileInfoVO();
					//file.setRbid();
					file.setFilename(saveFile);
					String fileType = fileName.substring(fileName.lastIndexOf("."));
					file.setFiletype(fileType);
					//dao.insertFileUpload
					
					}
			}
		

		}

		
		
	}
}
